<?php
/**
 * The header for our theme
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?></title>
    <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri() . '/style.css'); ?>">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <header class="site-header">
        <div class="header-container">
            <div class="site-branding">
                <h1 class="site-title"><a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></h1>
                <p class="site-description"><?php bloginfo('description'); ?></p>
            </div>
            <nav class="main-navigation">
                <ul class="nav-menu">
                    <li><a href="<?php echo esc_url(home_url('/')); ?>">ホーム</a></li>
                    <li><a href="<?php echo esc_url(home_url('/news-category/new-arrivals')); ?>">新着</a></li>
                    <li><a href="<?php echo esc_url(home_url('/news-category/news')); ?>">ニュース</a></li>
                    <li><a href="<?php echo esc_url(home_url('/news-category/graph-activities')); ?>">グラフ活動</a></li>
                    <li><a href="<?php echo esc_url(home_url('/news-category/exam-info')); ?>">入試情報</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <div class="site-content">
<?php
?>