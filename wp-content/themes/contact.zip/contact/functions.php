<?php

// Đăng ký taxonomy news_category nếu chưa có
add_action('init', function() {
    if (!taxonomy_exists('news_category')) {
        register_taxonomy('news_category', 'news', [
            'labels' => [
                'name' => __('News Categories', 'news-theme'),
                'singular_name' => __('News Category', 'news-theme'),
            ],
            'public' => true,
            'hierarchical' => true,
            'show_in_rest' => true,
        ]);
    }
});

// Hàm tạo args cho WP_Query
function get_news_query_args($params = []) {
    $defaults = [
        'posts_per_page' => 6,
        'post_type'      => 'news',
        'paged'          => 1,
        'post__not_in'   => get_option('sticky_posts', []),
        'order'          => 'DESC',
        'orderby'        => 'date',
        'post_status'    => 'publish',
    ];

    $args = wp_parse_args($params, $defaults);

    // Thêm tax_query nếu có danh mục
    if (!empty($params['category'])) {
        $args['tax_query'] = [
            [
                'taxonomy' => 'news_category',
                'field'    => 'slug',
                'terms'    => $params['category'],
            ],
        ];
    }

    return apply_filters('custom_news_query_args', $args);
}

// Xử lý AJAX request
add_action('wp_ajax_load_news_by_category', 'load_news_by_category');
add_action('wp_ajax_nopriv_load_news_by_category', 'load_news_by_category');

function load_news_by_category() {
    $category = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : '';
    $page = isset($_POST['page']) ? intval($_POST['page']) : 1;

    $args = get_news_query_args([
        'category' => $category,
        'paged'    => $page,
    ]);

    $query = new WP_Query($args);

    ob_start();
    if ($query->have_posts()) {
        echo '<div class="news-container">';
        while ($query->have_posts()) {
            $query->the_post();
            ?>
<div class="news-item">
    <?php if (has_post_thumbnail()) : ?>
    <a href="<?php the_permalink(); ?>" class="news-thumbnail">
        <?php the_post_thumbnail('medium'); ?>
    </a>
    <?php endif; ?>
    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
    <div class="news-excerpt"><?php the_excerpt(); ?></div>
</div>
<?php
        }
        echo '</div>';
        // Phân trang
        if ($query->max_num_pages > 1) {
            echo '<div class="news-pagination">';
            echo paginate_links([
                'total'   => $query->max_num_pages,
                'current' => $page,
                'format'  => '?paged=%#%',
                'add_args' => ['category' => $category],
                'prev_text' => __('« Trước', 'news-theme'),
                'next_text' => __('Tiếp »', 'news-theme'),
            ]);
            echo '</div>';
        }
    } else {
        echo '<p>' . __('Không tìm thấy bài viết nào.', 'news-theme') . '</p>';
    }
    $output = ob_get_clean();

    wp_send_json_success(['html' => $output]);
    wp_die();
}

// Đăng ký script và style
add_action('wp_enqueue_scripts', function() {
    // CSS
    wp_enqueue_style('style', get_template_directory_uri() . '/style.css', [], '1.0');
    // JS
    wp_enqueue_script('news-tabs-script', get_template_directory_uri() . '/news-tabs.js', ['jquery'], '1.0', true);
    wp_localize_script('news-tabs-script', 'newsTabs', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('news_tabs_nonce'),
    ]);
});

// Shortcode để hiển thị news tabs
add_shortcode('news_tabs', function() {
    ob_start();
    ?>
<div class="news-section">
    <div class="news-tabs">
        <?php
            $categories = [
                '' => __('新着', 'news-theme'), // Tất cả bài viết
                'news' => __('ニュース', 'news-theme'),
                'graph-activity' => __('グラフ活動', 'news-theme'),
                'exam-info' => __('入試情報', 'news-theme'),
            ];
            foreach ($categories as $slug => $name) {
                $class = $slug === '' ? 'active' : '';
                echo '<div class="news-tab ' . $class . '" data-category="' . esc_attr($slug) . '">' . esc_html($name) . '</div>';
            }
            ?>
    </div>
    <div class="news-container" id="news-container">
        <!-- Nội dung bài viết sẽ được tải bằng AJAX -->
    </div>
</div>
<?php
    return ob_get_clean();
});

add_action('after_setup_theme', function() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
});

?>