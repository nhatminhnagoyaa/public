<?php
/**
 * The footer for our theme
 */
?>
    </div><!-- .site-content -->
    <footer class="site-footer">
        <div class="footer-container">
            <div class="footer-info">
                <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved.</p>
                <p><?php bloginfo('description'); ?></p>
            </div>
            <div class="footer-nav">
                <ul>
                    <li><a href="<?php echo esc_url(home_url('/')); ?>">ホーム</a></li>
                    <li><a href="<?php echo esc_url(home_url('/news-category/new-arrivals')); ?>">新着</a></li>
                    <li><a href="<?php echo esc_url(home_url('/news-category/news')); ?>">ニュース</a></li>
                    <li><a href="<?php echo esc_url(home_url('/news-category/graph-activities')); ?>">グラフ活動</a></li>
                    <li><a href="<?php echo esc_url(home_url('/news-category/exam-info')); ?>">入試情報</a></li>
                </ul>
            </div>
        </div>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>
<?php
?>