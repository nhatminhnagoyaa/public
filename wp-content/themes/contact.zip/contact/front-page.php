<?php
/**
 * The template for displaying the front page
 */
get_header();
?>
<main class="front-page-content">
    <section class="news-section">
        <h2>新着 (New Arrivals)</h2>
        <?php echo do_shortcode('[news_tops category="new-arrivals" posts_per_page="3"]'); ?>
    </section>
    <section class="news-section">
        <h2>ニュース (News)</h2>
        <?php echo do_shortcode('[news_tops category="news" posts_per_page="3"]'); ?>
    </section>
    <section class="news-section">
        <h2>グラフ活動 (Graph Activities)</h2>
        <?php echo do_shortcode('[news_tops category="graph-activities" posts_per_page="3"]'); ?>
    </section>
    <section class="news-section">
        <h2>入試情報 (Exam Info)</h2>
        <?php echo do_shortcode('[news_tops category="exam-info" posts_per_page="3"]'); ?>
    </section>
</main>
<?php
get_footer();
?>